# Laba_1
 
